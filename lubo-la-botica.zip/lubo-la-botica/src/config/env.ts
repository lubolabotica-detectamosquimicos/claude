/**
 * Acceso centralizado y tipado a las variables de entorno.
 *
 * ⚠️  IMPORTANTE — todo lo que empieza con VITE_ termina DENTRO del JavaScript que se
 *     descarga en el navegador, es decir, es PÚBLICO. Aquí solo van valores públicos por
 *     diseño (config web de Firebase, enlaces de pago, correos de administrador).
 *     NUNCA pongas aquí: claves de servicio / Admin SDK de Firebase, tokens de Mercado Pago,
 *     claves de Gemini u otras API privadas. Esas, si algún día se usan, van en una
 *     función de servidor (Vercel Functions) con variables SIN prefijo VITE_.
 */

const read = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

export const ENV = {
  firebase: {
    apiKey: read(import.meta.env.VITE_FIREBASE_API_KEY),
    authDomain: read(import.meta.env.VITE_FIREBASE_AUTH_DOMAIN),
    projectId: read(import.meta.env.VITE_FIREBASE_PROJECT_ID),
    appId: read(import.meta.env.VITE_FIREBASE_APP_ID),
    storageBucket: read(import.meta.env.VITE_FIREBASE_STORAGE_BUCKET),
    messagingSenderId: read(import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID),
  },

  /** Correos autorizados para ver el Panel Administrativo (separados por coma). */
  adminEmails: read(import.meta.env.VITE_ADMIN_EMAILS)
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean),

  /** (Opcional) Enlace al Excel maestro en OneDrive, solo para el botón "Abrir en OneDrive" del panel admin. */
  oneDriveFileUrl: read(import.meta.env.VITE_ONEDRIVE_FILE_URL),

  /** Enlaces de pago. Si no se definen, se usan los enlaces oficiales actuales de LuBo. */
  paymentLinks: {
    monthly: read(import.meta.env.VITE_PAYMENT_LINK_MONTHLY) || 'https://mpago.li/1TxnQQk',
    annual: read(import.meta.env.VITE_PAYMENT_LINK_ANNUAL) || 'https://mpago.li/1uCi2kF',
    support:
      read(import.meta.env.VITE_PAYMENT_LINK_SUPPORT) ||
      'https://link.mercadopago.com.co/graciasporayudarnos',
  },
} as const;

/** True si están las 4 variables mínimas de Firebase Auth. */
export const isFirebaseConfigured: boolean =
  Boolean(ENV.firebase.apiKey) &&
  Boolean(ENV.firebase.authDomain) &&
  Boolean(ENV.firebase.projectId) &&
  Boolean(ENV.firebase.appId);

export const isAdminEmail = (email?: string | null): boolean =>
  Boolean(email) && ENV.adminEmails.includes(String(email).trim().toLowerCase());
