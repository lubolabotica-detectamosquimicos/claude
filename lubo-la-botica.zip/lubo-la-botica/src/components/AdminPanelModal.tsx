import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import { Ingredient, TrafficLight } from '../types';
import { ENV, isAdminEmail, isFirebaseConfigured } from '../config/env';
import { LocalVaultService } from '../services/localVault';
import { OneDriveSyncService } from '../services/oneDriveSync';
import { findDatabaseConflicts, getIngredientLight, searchIngredientsLocally } from '../services/ingredientMatcher';
import {
  friendlyAuthError,
  onAdminAuthChange,
  sendAdminPasswordReset,
  signInAdmin,
  signOutAdmin,
} from '../services/authService';

interface Props {
  onClose: () => void;
}

const LIGHT_DOT: Record<TrafficLight, string> = { green: 'bg-[#2A8743]', yellow: 'bg-[#EBB414]', red: 'bg-[#ba1a1a]' };
const LIGHT_LABEL: Record<TrafficLight, string> = { green: 'Verde', yellow: 'Amarillo', red: 'Rojo' };

const countLights = (list: Ingredient[]) => {
  const c = { green: 0, yellow: 0, red: 0 };
  list.forEach((i) => c[getIngredientLight(i)]++);
  return c;
};

/**
 * Panel administrativo. Acceso: Firebase Auth (correo + contraseña, una sola vez) y correo en VITE_ADMIN_EMAILS.
 * Edita la base de ingredientes LOCAL de este dispositivo (importando el CSV exportado del Excel de OneDrive).
 * La app nunca lee OneDrive por red: el archivo se descarga/exporta a mano y se importa aquí.
 */
const AdminPanelModal: React.FC<Props> = ({ onClose }) => {
  const [user, setUser] = useState<User | null | undefined>(isFirebaseConfigured ? undefined : null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    if (!isFirebaseConfigured) return;
    let unsub: (() => void) | undefined;
    let cancelled = false;
    onAdminAuthChange((u) => setUser(u))
      .then((fn) => (cancelled ? fn() : (unsub = fn)))
      .catch(() => setUser(null));
    return () => {
      cancelled = true;
      unsub?.();
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setAuthError(null);
    try {
      await signInAdmin(email, password);
      setPassword('');
    } catch (err) {
      setAuthError(friendlyAuthError(err));
    }
    setBusy(false);
  };

  const handleReset = async () => {
    if (!email.trim()) return setAuthError('Escribe tu correo arriba y vuelve a pulsar "Olvidé mi contraseña".');
    try {
      await sendAdminPasswordReset(email);
      setInfo('Te enviamos un correo para restablecer la contraseña.');
      setAuthError(null);
    } catch (err) {
      setAuthError(friendlyAuthError(err));
    }
  };

  const shell = (children: React.ReactNode) => (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm">
      <div className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto bg-white dark:bg-[#1a220a] rounded-3xl shadow-2xl border border-[#cce510]/60 text-[#341011] dark:text-[#f3f4e8]">
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-3 bg-gradient-to-r from-[#341011] to-[#4e1c1e] text-white">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#cce510] text-[20px]">admin_panel_settings</span>
            <h2 className="text-[15px] font-bold">Panel administrativo</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center cursor-pointer" title="Cerrar">
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>
        <div className="p-5 flex flex-col gap-4">{children}</div>
      </div>
    </div>
  );

  // 1) Firebase sin configurar
  if (!isFirebaseConfigured) {
    return shell(
      <div className="text-[12.5px] leading-relaxed flex flex-col gap-2">
        <p className="font-bold">Firebase no está configurado.</p>
        <p>
          Define <code>VITE_FIREBASE_API_KEY</code>, <code>VITE_FIREBASE_AUTH_DOMAIN</code>, <code>VITE_FIREBASE_PROJECT_ID</code> y{' '}
          <code>VITE_FIREBASE_APP_ID</code> (archivo <code>.env.local</code> en tu PC y "Environment Variables" en Vercel). Guía completa en el README.
        </p>
      </div>
    );
  }

  // 2) Cargando sesión
  if (user === undefined) return shell(<p className="text-[12.5px]">Comprobando sesión…</p>);

  // 3) Sin sesión → login (solo la primera vez)
  if (user === null) {
    return shell(
      <form onSubmit={handleLogin} className="flex flex-col gap-3">
        <p className="text-[12px] opacity-80">Inicia sesión una sola vez: el dispositivo recordará tu acceso.</p>
        <input
          type="email"
          required
          autoComplete="username"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Correo del administrador"
          className="px-3.5 py-2.5 rounded-xl bg-[#f3f3f4] dark:bg-white/10 border border-[#341011]/10 text-[13px] outline-none focus:ring-2 focus:ring-[#cce510]"
        />
        <input
          type="password"
          required
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Contraseña"
          className="px-3.5 py-2.5 rounded-xl bg-[#f3f3f4] dark:bg-white/10 border border-[#341011]/10 text-[13px] outline-none focus:ring-2 focus:ring-[#cce510]"
        />
        {authError && <p className="text-[12px] font-semibold text-[#ba1a1a]">{authError}</p>}
        {info && <p className="text-[12px] font-semibold text-[#2A8743]">{info}</p>}
        <button type="submit" disabled={busy} className="py-3 rounded-full bg-[#341011] text-[#cce510] text-[13px] font-extrabold disabled:opacity-50 cursor-pointer">
          {busy ? 'Entrando…' : 'Entrar'}
        </button>
        <button type="button" onClick={handleReset} className="text-[11px] font-bold underline opacity-70 cursor-pointer">
          Olvidé mi contraseña
        </button>
      </form>
    );
  }

  // 4) Con sesión pero sin permiso
  if (!isAdminEmail(user.email)) {
    return shell(
      <div className="flex flex-col gap-3 text-[12.5px]">
        <p className="font-bold text-[#ba1a1a]">Tu cuenta ({user.email}) no está autorizada como administradora.</p>
        {ENV.adminEmails.length === 0 && <p>No hay correos definidos en <code>VITE_ADMIN_EMAILS</code>.</p>}
        <button onClick={() => signOutAdmin()} className="py-2.5 rounded-full bg-[#341011] text-[#cce510] text-[12px] font-bold cursor-pointer">
          Cerrar sesión
        </button>
      </div>
    );
  }

  return shell(<AdminDashboard adminEmail={user.email || ''} />);
};

// ─────────────────────────────────────────────────────────────────────────────

const AdminDashboard: React.FC<{ adminEmail: string }> = ({ adminEmail }) => {
  const [ingredients, setIngredients] = useState<Ingredient[]>(() => LocalVaultService.getIngredients());
  const [query, setQuery] = useState('');
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [pending, setPending] = useState<{ list: Ingredient[]; source: string; warnings: string[]; errors: string[] } | null>(null);
  const [form, setForm] = useState<{ id?: string; name: string; light: TrafficLight; risk: string; synonyms: string } | null>(null);
  const csvRef = useRef<HTMLInputElement | null>(null);
  const jsonRef = useRef<HTMLInputElement | null>(null);

  const meta = LocalVaultService.getSyncMetadata();
  const counts = useMemo(() => countLights(ingredients), [ingredients]);
  const conflicts = useMemo(() => findDatabaseConflicts(ingredients), [ingredients]);
  const results = useMemo(() => (query.trim() ? searchIngredientsLocally(query, ingredients).slice(0, 12) : []), [query, ingredients]);

  const ok = (text: string) => setMessage({ kind: 'ok', text });
  const fail = (text: string) => setMessage({ kind: 'error', text });
  const reload = () => setIngredients([...LocalVaultService.getIngredients()]);

  const download = (content: string, filename: string, type: string) => {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const onCsv = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const result = OneDriveSyncService.parseOneDriveCsv(await file.text());
    if (!result.success) return fail(result.errors[0] || 'No se pudo leer el CSV.');
    setPending({ list: result.ingredients, source: `CSV de OneDrive (${file.name})`, warnings: result.warnings, errors: result.errors });
    setMessage(null);
  };

  const onJson = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const v = LocalVaultService.validateIngredientsJson(await file.text());
    if (!v.valid || !v.parsed) return fail(v.error || 'JSON no válido.');
    setPending({ list: v.parsed, source: `JSON (${file.name})`, warnings: [], errors: [] });
    setMessage(null);
  };

  const applyPending = () => {
    if (!pending) return;
    LocalVaultService.createSnapshot();
    if (LocalVaultService.saveIngredients(pending.list, pending.source)) {
      ok(`Base actualizada: ${pending.list.length} ingredientes. Se guardó una copia de respaldo anterior.`);
      reload();
    } else fail('No se pudo guardar (almacenamiento lleno). Libera espacio e inténtalo de nuevo.');
    setPending(null);
  };

  const saveForm = () => {
    if (!form || !form.name.trim()) return fail('El nombre es obligatorio.');
    const base = ingredients.find((i) => i.id === form.id);
    const syns = form.synonyms.split(',').map((s) => s.trim()).filter(Boolean);
    LocalVaultService.upsertIngredient({
      ...(base || {}),
      id: form.id || `lubo-custom-${Date.now()}`,
      name: form.name.trim(),
      inciName: base?.inciName || form.name.trim(),
      trafficLight: form.light,
      tier: form.light === 'red' ? 'danger' : form.light === 'yellow' ? 'caution' : 'optimal',
      functionalRiskOrBenefit: form.risk.trim(),
      synonyms: syns.length ? syns : base?.synonyms || [form.name.trim().toLowerCase()],
    } as Ingredient);
    ok(`"${form.name.trim()}" guardado.`);
    setForm(null);
    reload();
  };

  const removeIngredient = (ing: Ingredient) => {
    if (!window.confirm(`¿Eliminar "${ing.name}" de la base local?`)) return;
    LocalVaultService.deleteIngredient(ing.id);
    ok(`"${ing.name}" eliminado.`);
    reload();
  };

  const btn = 'px-3 py-2 rounded-xl text-[11.5px] font-bold cursor-pointer transition-colors';
  const btnDark = `${btn} bg-[#341011] text-[#cce510] hover:bg-black`;
  const btnSoft = `${btn} bg-[#f3f3f4] dark:bg-white/10 hover:bg-[#cce510] hover:text-[#341011]`;

  return (
    <>
      <div className="flex items-center justify-between text-[11px]">
        <span className="opacity-70 truncate">Sesión: {adminEmail}</span>
        <button onClick={() => signOutAdmin()} className="font-bold underline cursor-pointer shrink-0 ml-2">Cerrar sesión</button>
      </div>

      {message && (
        <div className={`text-[12px] font-semibold rounded-xl px-3 py-2 ${message.kind === 'ok' ? 'bg-[#2A8743]/15 text-[#1d6130] dark:text-[#a1e687]' : 'bg-[#ba1a1a]/15 text-[#93000a] dark:text-[#ffb4ab]'}`}>
          {message.text}
        </div>
      )}

      {/* Estado de la base */}
      <section className="rounded-2xl border border-[#341011]/10 dark:border-white/10 p-3.5 flex flex-col gap-1.5">
        <h3 className="text-[11px] font-extrabold uppercase tracking-wider">Base de ingredientes de este dispositivo</h3>
        <p className="text-[12px]"><strong>{ingredients.length}</strong> ingredientes · fuente: {meta.source}</p>
        {meta.lastSyncDate && <p className="text-[11px] opacity-70">Última actualización: {new Date(meta.lastSyncDate).toLocaleString('es-CO')} · {meta.checksum}</p>}
        <div className="flex gap-3 text-[12px] font-bold">
          {(['green', 'yellow', 'red'] as TrafficLight[]).map((l) => (
            <span key={l} className="flex items-center gap-1"><span className={`w-2.5 h-2.5 rounded-full ${LIGHT_DOT[l]}`} />{counts[l]} {LIGHT_LABEL[l]}</span>
          ))}
        </div>
        {counts.yellow === 0 && <p className="text-[11px] text-[#6b5000] dark:text-[#f5d56b]">⚠️ No hay ningún ingrediente en AMARILLO: el semáforo solo podrá mostrar verde o rojo.</p>}
      </section>

      {/* Importar / exportar */}
      <section className="flex flex-col gap-2">
        <h3 className="text-[11px] font-extrabold uppercase tracking-wider">Actualizar desde tu archivo de OneDrive</h3>
        <p className="text-[11.5px] opacity-80 leading-snug">
          1) Abre tu Excel en OneDrive → <em>Archivo ▸ Guardar como ▸ CSV UTF-8</em>. 2) Impórtalo aquí. La app nunca lee OneDrive por internet.
        </p>
        <div className="flex flex-wrap gap-2">
          <input ref={csvRef} type="file" accept=".csv,text/csv" className="hidden" onChange={onCsv} />
          <input ref={jsonRef} type="file" accept=".json,application/json" className="hidden" onChange={onJson} />
          <button className={btnDark} onClick={() => csvRef.current?.click()}>Importar CSV</button>
          <button className={btnSoft} onClick={() => jsonRef.current?.click()}>Importar JSON</button>
          <button className={btnSoft} onClick={() => OneDriveSyncService.downloadOneDriveTemplate(ingredients)}>Exportar CSV</button>
          <button className={btnSoft} onClick={() => download(LocalVaultService.exportVault(), `lubo-base-${new Date().toISOString().slice(0, 10)}.json`, 'application/json')}>Exportar JSON</button>
          {ENV.oneDriveFileUrl && (
            <a className={btnSoft} href={ENV.oneDriveFileUrl} target="_blank" rel="noopener noreferrer">Abrir en OneDrive ↗</a>
          )}
        </div>

        {pending && (
          <div className="rounded-2xl border-2 border-[#cce510] p-3 flex flex-col gap-2 bg-[#cce510]/10">
            <p className="text-[12px] font-bold">Vista previa de la importación: {pending.list.length} ingredientes</p>
            <div className="flex gap-3 text-[11.5px] font-bold">
              {(['green', 'yellow', 'red'] as TrafficLight[]).map((l) => (
                <span key={l} className="flex items-center gap-1"><span className={`w-2.5 h-2.5 rounded-full ${LIGHT_DOT[l]}`} />{countLights(pending.list)[l]}</span>
              ))}
            </div>
            {pending.list.length < ingredients.length * 0.5 && (
              <p className="text-[11.5px] font-semibold text-[#ba1a1a]">⚠️ La nueva lista tiene menos de la mitad de ingredientes que la actual. ¿Es el archivo correcto?</p>
            )}
            {pending.warnings.length > 0 && (
              <details className="text-[11px]"><summary className="cursor-pointer font-bold">{pending.warnings.length} aviso(s)</summary>
                <ul className="list-disc pl-4 mt-1 max-h-24 overflow-y-auto">{pending.warnings.slice(0, 30).map((w, i) => <li key={i}>{w}</li>)}</ul>
              </details>
            )}
            {pending.errors.length > 0 && (
              <details className="text-[11px]"><summary className="cursor-pointer font-bold text-[#ba1a1a]">{pending.errors.length} fila(s) omitida(s)</summary>
                <ul className="list-disc pl-4 mt-1 max-h-24 overflow-y-auto">{pending.errors.slice(0, 30).map((w, i) => <li key={i}>{w}</li>)}</ul>
              </details>
            )}
            <div className="flex gap-2">
              <button className={btnDark} onClick={applyPending}>Aplicar</button>
              <button className={btnSoft} onClick={() => setPending(null)}>Cancelar</button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {LocalVaultService.hasSnapshot() && (
            <button className={btnSoft} onClick={() => { const r = LocalVaultService.restoreSnapshot(); if (r) { ok('Copia de respaldo restaurada.'); reload(); } else fail('No hay copia de respaldo.'); }}>Restaurar respaldo</button>
          )}
          {LocalVaultService.isCustomDatabase() && (
            <button className={btnSoft} onClick={() => { if (window.confirm('¿Volver a la base oficial incluida en la app?')) { LocalVaultService.resetToDefaultIngredients(); ok('Base oficial restaurada.'); reload(); } }}>Volver a la base de fábrica</button>
          )}
        </div>
      </section>

      {/* Buscar / editar */}
      <section className="flex flex-col gap-2">
        <h3 className="text-[11px] font-extrabold uppercase tracking-wider">Buscar y editar ingredientes</h3>
        <div className="flex gap-2">
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar en la base…" className="flex-1 px-3 py-2 rounded-xl bg-[#f3f3f4] dark:bg-white/10 text-[12.5px] outline-none focus:ring-2 focus:ring-[#cce510]" />
          <button className={btnDark} onClick={() => setForm({ name: '', light: 'green', risk: '', synonyms: '' })}>+ Nuevo</button>
        </div>
        {results.map((ing) => (
          <div key={ing.id} className="flex items-center justify-between gap-2 text-[12px] bg-[#f3f3f4] dark:bg-white/5 rounded-lg px-2.5 py-1.5">
            <span className="flex items-center gap-2 min-w-0"><span className={`w-2.5 h-2.5 rounded-full shrink-0 ${LIGHT_DOT[getIngredientLight(ing)]}`} /><span className="font-bold truncate">{ing.name}</span></span>
            <span className="flex gap-2 shrink-0">
              <button className="font-bold underline cursor-pointer" onClick={() => setForm({ id: ing.id, name: ing.name, light: getIngredientLight(ing), risk: ing.functionalRiskOrBenefit || '', synonyms: (ing.synonyms || []).join(', ') })}>Editar</button>
              <button className="font-bold underline text-[#ba1a1a] cursor-pointer" onClick={() => removeIngredient(ing)}>Borrar</button>
            </span>
          </div>
        ))}
        {form && (
          <div className="rounded-2xl border border-[#341011]/15 dark:border-white/15 p-3 flex flex-col gap-2">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Nombre del ingrediente" className="px-3 py-2 rounded-xl bg-[#f3f3f4] dark:bg-white/10 text-[12.5px] outline-none" />
            <div className="flex gap-2">
              {(['green', 'yellow', 'red'] as TrafficLight[]).map((l) => (
                <button key={l} type="button" onClick={() => setForm({ ...form, light: l })} className={`flex-1 py-2 rounded-xl text-[11.5px] font-bold border-2 cursor-pointer ${form.light === l ? 'border-[#341011] dark:border-[#cce510]' : 'border-transparent bg-[#f3f3f4] dark:bg-white/10'}`}>
                  <span className={`inline-block w-2.5 h-2.5 rounded-full mr-1 ${LIGHT_DOT[l]}`} />{LIGHT_LABEL[l]}
                </button>
              ))}
            </div>
            <textarea value={form.risk} onChange={(e) => setForm({ ...form, risk: e.target.value })} rows={2} placeholder="Riesgo funcional o beneficio (texto que verá el usuario)" className="px-3 py-2 rounded-xl bg-[#f3f3f4] dark:bg-white/10 text-[12.5px] outline-none resize-none" />
            <input value={form.synonyms} onChange={(e) => setForm({ ...form, synonyms: e.target.value })} placeholder="Sinónimos separados por coma (ej. glycerin, glicerol)" className="px-3 py-2 rounded-xl bg-[#f3f3f4] dark:bg-white/10 text-[12.5px] outline-none" />
            <div className="flex gap-2"><button className={btnDark} onClick={saveForm}>Guardar</button><button className={btnSoft} onClick={() => setForm(null)}>Cancelar</button></div>
          </div>
        )}
      </section>

      {/* Calidad */}
      {conflicts.length > 0 && (
        <section className="flex flex-col gap-1.5">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider">Revisión de la base ({conflicts.length})</h3>
          <p className="text-[11.5px] opacity-80 leading-snug">Estos términos apuntan a ingredientes con semáforo distinto. El motor usa el de coincidencia exacta con el nombre; conviene unificar en el Excel.</p>
          <ul className="text-[11.5px] list-disc pl-4 max-h-28 overflow-y-auto">
            {conflicts.slice(0, 20).map((c) => (
              <li key={c.term}><strong>{c.term}</strong>: {c.entries.map((e) => `${e.name} (${LIGHT_LABEL[e.light]})`).join(' vs ')}</li>
            ))}
          </ul>
        </section>
      )}
    </>
  );
};

export default AdminPanelModal;
