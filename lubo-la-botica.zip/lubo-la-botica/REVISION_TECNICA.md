# Revisión técnica — LuBo la botica

## 1. Errores críticos encontrados y corregidos

| # | Hallazgo | Estado |
|---|---|---|
| 1 | **El escáner no escaneaba**: la cámara era una simulación (sin captura ni OCR); la lógica real estaba en un componente sin conectar. | ✅ Flujo real: captura → vista previa → OCR local → semáforo |
| 2 | **OCR descargaba worker, WASM y modelos desde cdn.jsdelivr.net** (violaba "nunca en la red"). | ✅ Recursos locales en `/ocr`; verificado en navegador: 0 peticiones a CDN |
| 3 | **PIN maestro, llaves de dueño y correo del dueño en el código** (públicos al subir a GitHub). | ✅ Eliminados |
| 4 | **Todo visitante nuevo era "paid" y "dueño"**, con el perfil de "Camila Valenzuela" y 48 escaneos de ejemplo. | ✅ Usuario nuevo = Free, perfil y historial vacíos |
| 5 | Motor de clasificación por subcadenas: *Salicylic Acid* → "Sal" (verde falso); *Cetearyl Alcohol* → DEA/TEA/MEA (rojo falso); *Sodium Hyaluronate* → "Sodium" (rojo falso). La propia muestra "100% limpio" salía **roja**. | ✅ Coincidencia por palabra completa (+ 50 pruebas) |
| 6 | **Texto sin coincidencias salía en VERDE.** | ✅ Nuevo estado "Sin datos" |
| 7 | `<video>` nunca recibía el stream (pantalla negra). | ✅ Corregido y verificado |
| 8 | Cada escaneo descontaba **2** de la cuota; el texto manual consumía cuota de cámara y se bloqueaba. | ✅ 1 descuento por foto; texto siempre ilimitado |
| 9 | Descifrar ~500 KB de `localStorage` **en cada tecla**. | ✅ Caché en memoria |
| 10 | Una lista editada por el admin con menos de 680 filas se **sobrescribía** con la de fábrica. | ✅ Se respeta la lista personalizada |
| 11 | Historial y favoritos se perdían al recargar; los escaneos nuevos no se podían guardar. | ✅ Persistentes |
| 12 | `npm install` fallaba (conflicto `esbuild`/Vite) → fallaría en Vercel. | ✅ Dependencias limpias; `npm ci` verificado |
| 13 | Enlace compartido de tu OneDrive dentro del código. | ✅ Movido a variable opcional |
| 14 | Usuarios podían editar los enlaces de pago en pantalla; formulario con datos personales por defecto. | ✅ Quitado |
| 15 | Fuentes e iconos desde Google Fonts (sin internet los iconos salían como texto). | ✅ Alojados localmente |
| 16 | Sin botón de modo oscuro; animaciones con clases inexistentes; zoom bloqueado (accesibilidad). | ✅ Corregido |
| 17 | Dependencias muertas (`@google/genai`, `express`, `dotenv`, `motion`, `canvas-confetti`…), 2 componentes huérfanos. | ✅ Eliminadas |

## 2. Lo que NO estaba y se agregó
Firebase Auth (sesión persistente) + Panel administrativo (importar/exportar CSV/JSON, editar, respaldo, revisión de la base).

## 3. Problemas en TUS DATOS (decisión del dueño)
* **0 ingredientes en amarillo** (633 verdes, 47 rojos): el semáforo nunca mostrará amarillo salvo que los marques en el Excel.
* **Conflictos de color:** `Azúcar` (rojo) vs `Azúcar (sacarosa)` (verde); `Carragenina` (rojo) vs `Carragenina (natural)` (verde).
* **Cobertura baja para cosméticos:** no están `Agua/Aqua`, `Glicerina/Glycerin`, `Ácido cítrico`, `Niacinamida`, `Fenoxietanol`, `Pantenol`, etc. Se mostrarán como "no reconocidos". Conviene ampliar la lista (nombres en español **e** INCI).
* **Sinónimos basura** generados al convertir el Excel (`pulpa`, `agua)`, `gel`…): el motor los ignora, pero conviene limpiarlos en el Excel.
* **Entradas comodín** `Sodium` y `Ammonium` (rojo): el motor las aplica solo si el término es exactamente esa palabra.

## 4. Pendiente / no verificado
* 🔴 **Verificación de pagos:** el plan de pago se activa sin comprobar el pago (ver README). Requiere decisión: códigos firmados o webhook.
* **"Cifrado local":** es ligero (llave aleatoria por dispositivo); no es barrera de seguridad frente al propio usuario.
* No probado: login real de Firebase (sin credenciales), cámara de un celular físico (se probó con cámara simulada de Chromium) ni el despliegue real en Vercel (se simuló `npm ci` + build).
* Imágenes de productos de muestra y logo siguen en URLs externas (AI Studio / Unsplash): guárdalas en `public/` antes de producción.
* Precios del catálogo de muestra están en `priceMxn` (pesos mexicanos) mientras la app cobra en COP.
