# 🌿 LuBo la botica — Lector de ingredientes con semáforo

Web app (lista para crecer a app móvil) que **escanea la etiqueta de ingredientes con la cámara del celular** y
muestra un **semáforo LuBo** (verde / amarillo / rojo) según la lista maestra de LuBo.

> **Regla de oro:** la clasificación es **100 % local**. La foto, el OCR y el semáforo funcionan en el dispositivo,
> sin consultar internet ni bases de datos externas. Funciona sin conexión una vez cargada la app.

---

## Qué hace

| Función | Detalle |
|---|---|
| 📷 Escáner | Captura foto → vista previa → OCR local (Tesseract, español + inglés) → semáforo. Si la cámara está denegada, permite subir/tomar una foto. |
| ⌨️ Texto manual | Escribe un ingrediente o pega la lista → semáforo al instante. **Ilimitado en todos los planes.** |
| 🚦 Semáforo | Verde / Amarillo / Rojo / *Sin datos* (si nada coincide con la base, **nunca** se muestra verde). |
| 📋 Base LuBo | 680 ingredientes incluidos en la app. Editable desde el Excel de OneDrive (se exporta a CSV y se importa en el Panel administrativo). |
| 💳 Planes | Free (2 escaneos de cámara/semana) · Mensual · Anual · Aporte voluntario. Cada uno con su enlace de pago. |
| 🔐 Panel admin | Firebase Auth (correo + contraseña), **se inicia sesión una sola vez**. Importar/exportar/editar la base. |

---

## Arquitectura por capas

```
┌──────────────────────────────────────────────────────────────────────┐
│ 1. INTERACTIVA  (src/components)                                     │
│    ScanScreen · CameraViewfinderModal · FichaTecnicaModal ·          │
│    HistoryScreen · SavedScreen · ProfileScreen · InicioFormModal ·   │
│    AdminPanelModal (carga diferida) · TrafficLightBadge              │
├──────────────────────────────────────────────────────────────────────┤
│ 2. PROCESAMIENTO  (src/services)                                     │
│    ingredientMatcher  → clasifica texto contra la base (offline)     │
│    ocrService         → Tesseract en el dispositivo (assets locales) │
│    productFactory     → análisis → ficha de producto                 │
├──────────────────────────────────────────────────────────────────────┤
│ 3. BACKEND / DATOS  (src/services + src/config + src/data)           │
│    localVault   → base y sesión en el dispositivo (cifrado ligero)   │
│    oneDriveSync → importa/exporta CSV del Excel de OneDrive          │
│    authService  → Firebase Auth (solo panel admin, carga diferida)   │
│    config/env · config/plans · data/initialIngredients               │
└──────────────────────────────────────────────────────────────────────┘
```

Las capas solo dependen hacia abajo: la interfaz llama a procesamiento y datos; el procesamiento no conoce la interfaz.
Firebase **no se carga** para escanear: solo cuando se abre el Panel administrativo.

---

## Inicio rápido (tu computador)

Requisitos: **Node.js 20 o superior**.

```bash
npm install            # instala y copia los recursos del OCR a public/ocr (automático)
cp .env.example .env.local   # y rellena tus valores (ver más abajo)
npm run dev            # http://localhost:5173
```

Otros comandos: `npm test` (pruebas del motor) · `npm run lint` (tipos) · `npm run build` · `npm run preview`.

> **Cámara:** el navegador solo permite la cámara en **HTTPS** o en `localhost`. En Vercel ya es HTTPS.

---

## Variables de entorno

Copia `.env.example` → `.env.local` (no se sube a GitHub). En Vercel: *Project ▸ Settings ▸ Environment Variables*.

| Variable | Obligatoria | Para qué |
|---|---|---|
| `VITE_FIREBASE_API_KEY` | Para el panel admin | Config web de Firebase |
| `VITE_FIREBASE_AUTH_DOMAIN` | Para el panel admin | `tu-proyecto.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | Para el panel admin | ID del proyecto |
| `VITE_FIREBASE_APP_ID` | Para el panel admin | ID de la app web |
| `VITE_ADMIN_EMAILS` | Para el panel admin | Correos autorizados, separados por coma |
| `VITE_PAYMENT_LINK_MONTHLY` / `_ANNUAL` / `_SUPPORT` | Opcional | Enlaces de pago (si faltan, se usan los actuales) |
| `VITE_ONEDRIVE_FILE_URL` | Opcional | Botón “Abrir en OneDrive” del panel admin |

### ⚠️ Qué es público y qué no

Todo lo que empieza con `VITE_` **queda dentro del JavaScript del navegador** (cualquiera puede verlo). Por eso aquí solo
van valores públicos por diseño. La *apiKey* web de Firebase es un identificador público: su seguridad depende de los
**Dominios autorizados** (Firebase ▸ Authentication ▸ Settings) y de las reglas, no de ocultarla.

**Nunca** pongas en variables `VITE_*` ni en el repositorio: claves de *service account* / Admin SDK de Firebase, tokens
privados de Mercado Pago, claves de Gemini u otras API. Si algún día se necesitan, van en una función de servidor
(Vercel Functions) con variables **sin** prefijo `VITE_`.

---

## Configurar Firebase (una sola vez)

1. [console.firebase.google.com](https://console.firebase.google.com) → *Crear proyecto*.
2. *Authentication ▸ Sign-in method* → activa **Correo electrónico/contraseña**.
3. *Authentication ▸ Users* → **Agregar usuario** con tu correo de administrador y una contraseña.
   (No hay registro público: nadie más puede crear cuentas desde la app.)
4. *Authentication ▸ Settings ▸ Authorized domains* → añade tu dominio de Vercel (`xxx.vercel.app` y el dominio propio).
5. *Configuración del proyecto ▸ Tus apps ▸ Web (`</>`)* → copia la config a las variables `VITE_FIREBASE_*`.
6. Pon tu correo en `VITE_ADMIN_EMAILS`.

En la app: **Perfil ▸ Panel administrativo**. Inicias sesión una vez; el dispositivo recuerda la sesión (también sin internet).

---

## Subir a GitHub y desplegar en Vercel

```bash
git init
git add .
git commit -m "LuBo la botica v1.0.0"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/lubo-la-botica.git
git push -u origin main
```

Antes del primer `git push` verifica que **no** se suba nada secreto: `git status` no debe listar `.env.local`
(el `.gitignore` ya lo excluye). Recomendado: repositorio **privado**.

En Vercel: *Add New ▸ Project ▸ Import* el repositorio. Vercel detecta Vite y usa `npm run build`
(`vercel.json` ya incluye cabeceras de seguridad y permiso de cámara). Añade las variables de entorno y despliega.
El paso `postinstall` copia los recursos del OCR automáticamente.

---

## Actualizar la lista de ingredientes (flujo OneDrive)

La app **nunca lee OneDrive por internet**. El flujo es manual y seguro:

1. En OneDrive abre tu Excel → *Archivo ▸ Guardar como ▸ CSV UTF-8*.
2. En la app: **Perfil ▸ Panel administrativo ▸ Importar CSV**.
3. Revisa la vista previa (conteo por color, avisos) y pulsa **Aplicar**. Se guarda un respaldo automático del estado anterior.

Columnas del CSV: `Categoria_Color; Químico; Uso principal; Riesgo funcional o Beneficio; Nivel de toxisidad (%); Producto donde se usa más`.
Colores válidos: Verde, Amarillo, Rojo. Un color desconocido se trata como **Rojo** y genera un aviso.

> La base que importas se guarda **en ese dispositivo**. Para que *todos* los usuarios reciban una lista nueva, actualiza
> `src/data/initialIngredients.ts` y vuelve a desplegar.

---

## Planes y pagos

| Plan | Escaneos con cámara | Texto manual |
|---|---|---|
| Free | 2 por semana | Ilimitado |
| Mensual ($6.500 COP) | Ilimitado · 30 días | Ilimitado |
| Anual ($30.000 COP) | Ilimitado · 365 días | Ilimitado |
| Aporte voluntario | Enlace de pago adicional | — |

Precios y límites: `src/config/plans.ts`. Enlaces de pago: variables `VITE_PAYMENT_LINK_*`.

### ⚠️ Limitación conocida — verificación de pagos

Hoy el plan de pago **se activa cuando la persona lo confirma en el formulario**, sin comprobar el pago. Con enlaces
estáticos de Mercado Pago y sin servidor no hay forma de verificarlo, y un usuario técnico podría auto-otorgarse un plan.
Antes de cobrar a escala, elige una de estas rutas:

1. **Códigos de activación firmados (encaja con tu modelo offline):** tú generas un código por pago confirmado; la app lo
   valida localmente con una clave pública y lo guarda en la bóveda local.
2. **Webhook de Mercado Pago → Firebase (Firestore + Vercel Function):** el pago habilita al correo del usuario; la app consulta
   solo el estado de suscripción (la clasificación sigue siendo 100 % local).

---

## Seguridad: lo que sí y lo que no garantiza

* ✅ Sin llaves, PIN ni correos de dueño en el código. Sin enlaces de pago editables por el usuario.
* ✅ La bóveda local usa una llave **aleatoria por dispositivo** (no está en el repositorio).
* ⚠️ Cifrado local ≠ barrera de seguridad: protege de lecturas casuales, no de quien controla su propio navegador.
* ⚠️ El acceso al panel admin se valida con Firebase + `VITE_ADMIN_EMAILS`, pero el panel solo edita la base **local** del
  dispositivo (no hay datos de servidor que proteger). Si más adelante usas Firestore, define **reglas de seguridad** estrictas.

---

## Pruebas

```bash
npm test
```

Cubre el motor de clasificación: falsos positivos históricos (“Salicylic Acid” → “Sal”), estado *Sin datos*, E-números,
tokenizador/OCR, integridad de la base y el importador CSV.

---

## Estructura

```
├─ public/ocr/            ← (generado) worker, núcleo WASM y modelos spa/eng del OCR
├─ scripts/
│  ├─ copy-ocr-assets.mjs ← copia los recursos del OCR (postinstall)
│  └─ test-matcher.ts     ← pruebas del motor
├─ src/
│  ├─ components/         ← capa interactiva
│  ├─ services/           ← procesamiento y datos
│  ├─ config/             ← env.ts, plans.ts
│  ├─ data/               ← base LuBo, datos de muestra
│  ├─ types/
│  └─ App.tsx · main.tsx · index.css
├─ .env.example · .gitignore · vercel.json · vite.config.ts · tsconfig.json
```

`StorePreview.tsx` y `data/productSuggestions.ts` corresponden a la futura fase de **sugerencias y venta de producto**:
están en el repositorio pero todavía no se muestran en la app.

---

## Solución de problemas

* **“Permiso de cámara denegado”** → actívalo en el candado de la barra de direcciones, o usa el botón de galería para subir una foto.
* **El OCR no encuentra texto** → acércate a la lista de ingredientes, buena luz, sin reflejos. Puedes corregir el texto leído antes de clasificar.
* **Avisos `EBADENGINE` al instalar** → son advertencias del SDK de Firebase; no afectan (corre en el navegador).
* **“Firebase no está configurado”** → faltan las variables `VITE_FIREBASE_*` (ver arriba) y hay que reiniciar `npm run dev`.

---

© LuBo la botica · Certificación Vida sin Químicos
